const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const crypto = require('crypto');

app.use(express.static(__dirname + '/public'));

const ROOM_CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const MATCH_TARGET_SCORE = 7;
const RECONNECT_GRACE_MS = 90 * 1000;

/** rooms[code] = {
 *   code, players: [player, player], deck, table, turn, started,
 *   lastCapturedBy, matchScore: [0,0], handNumber
 * }
 * player = { token, socketId, name, connected, hand, captured, sweeps, disconnectTimer }
 */
const rooms = {};

function genToken() {
  return crypto.randomBytes(12).toString('hex');
}

function genRoomCode() {
  let code;
  do {
    code = Array.from({ length: 4 }, () => ROOM_CODE_CHARS[Math.floor(Math.random() * ROOM_CODE_CHARS.length)]).join('');
  } while (rooms[code]);
  return code;
}

const SUITS = ['♠', '♥', '♦', '♣'];
const RANKS = [
  { n: 'A', v: 1 }, { n: '2', v: 2 }, { n: '3', v: 3 }, { n: '4', v: 4 }, { n: '5', v: 5 },
  { n: '6', v: 6 }, { n: '7', v: 7 }, { n: '8', v: 8 }, { n: '9', v: 9 }, { n: '10', v: 10 },
  { n: 'J', v: 11 }, { n: 'Q', v: 12 }, { n: 'K', v: 13 }
];

function freshDeck() {
  let id = 0;
  const deck = [];
  for (const suit of SUITS) {
    for (const r of RANKS) {
      deck.push({
        id: 'c' + (id++),
        suit, rank: r.n, value: r.v,
        color: (suit === '♥' || suit === '♦') ? 'red' : 'black',
        sumEligible: r.n !== 'J' && r.n !== 'Q' && r.n !== 'K'
      });
    }
  }
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

function dealHand(room) {
  room.deck = freshDeck();
  room.table = [];
  room.players.forEach(p => { p.hand = []; p.captured = []; p.sweeps = 0; });
  room.lastCapturedBy = null;

  // redeal if any of the initial 4 table cards is a Jack (standard rule)
  let attempt = 0;
  do {
    room.deck = attempt === 0 ? room.deck : freshDeck();
    room.table = room.deck.splice(0, 4);
    attempt++;
  } while (room.table.some(c => c.rank === 'J') && attempt < 20);

  room.players[0].hand = room.deck.splice(0, 4);
  room.players[1].hand = room.deck.splice(0, 4);
  room.turn = room.handNumber % 2; // alternate who starts each hand
  room.handNumber++;
}

function dealMoreIfNeeded(room) {
  if (room.players[0].hand.length === 0 && room.players[1].hand.length === 0 && room.deck.length > 0) {
    const count = Math.min(4, Math.floor(room.deck.length / 2)) || Math.min(1, room.deck.length);
    room.players[0].hand = room.deck.splice(0, count);
    room.players[1].hand = room.deck.splice(0, count);
  }
}

function handIsOver(room) {
  return room.deck.length === 0 && room.players[0].hand.length === 0 && room.players[1].hand.length === 0;
}

function scoreHand(room) {
  const [p1, p2] = room.players;
  const result = { breakdown: [], points: [0, 0] };

  const clubs = [p1.captured.filter(c => c.suit === '♣').length, p2.captured.filter(c => c.suit === '♣').length];
  const totalCards = [p1.captured.length, p2.captured.length];

  if (totalCards[0] !== totalCards[1]) {
    const w = totalCards[0] > totalCards[1] ? 0 : 1;
    result.points[w] += 3;
    result.breakdown.push(`بیشترین ورق: بازیکن ${w + 1} (+۳)`);
  }
  if (clubs[0] !== clubs[1]) {
    const w = clubs[0] > clubs[1] ? 0 : 1;
    result.points[w] += 3;
    result.breakdown.push(`بیشترین گشنیز ♣: بازیکن ${w + 1} (+۳)`);
  }
  for (const p of [0, 1]) {
    if (room.players[p].captured.some(c => c.suit === '♣' && c.rank === '2')) {
      result.points[p] += 2;
      result.breakdown.push(`۲ گشنیز: بازیکن ${p + 1} (+۲)`);
    }
    if (room.players[p].captured.some(c => c.suit === '♦' && c.rank === '10')) {
      result.points[p] += 3;
      result.breakdown.push(`۱۰ خشت: بازیکن ${p + 1} (+۳)`);
    }
    const aces = room.players[p].captured.filter(c => c.rank === 'A').length;
    if (aces > 0) {
      result.points[p] += aces;
      result.breakdown.push(`${aces} آس: بازیکن ${p + 1} (+${aces})`);
    }
    if (room.players[p].sweeps > 0) {
      result.points[p] += room.players[p].sweeps;
      result.breakdown.push(`${room.players[p].sweeps} پاسور (جمع‌کردن کامل میز): بازیکن ${p + 1} (+${room.players[p].sweeps})`);
    }
  }
  return result;
}

function publicState(room, forIndex) {
  const me = room.players[forIndex];
  const opp = room.players[1 - forIndex];
  return {
    hand: me.hand,
    table: room.table,
    turn: room.turn,
    myIndex: forIndex,
    opponentCardCount: opp.hand.length,
    myCaptured: me.captured.length,
    oppCaptured: opp.captured.length,
    mySweeps: me.sweeps,
    oppSweeps: opp.sweeps,
    matchScore: room.matchScore,
    deckCount: room.deck.length,
    opponentConnected: opp.connected,
    opponentName: opp.name
  };
}

function broadcastState(room, note) {
  room.players.forEach((p, idx) => {
    if (p.socketId) {
      io.to(p.socketId).emit('state-update', { ...publicState(room, idx), note: note || null });
    }
  });
}

function roomSummary(room) {
  return {
    code: room.code,
    started: room.started,
    players: room.players.map(p => ({ name: p.name, connected: p.connected }))
  };
}

io.on('connection', (socket) => {
  socket.on('create-room', ({ name }) => {
    const code = genRoomCode();
    const token = genToken();
    const room = {
      code,
      players: [
        { token, socketId: socket.id, name: (name || 'بازیکن ۱').slice(0, 20), connected: true, hand: [], captured: [], sweeps: 0, disconnectTimer: null }
      ],
      deck: [], table: [], turn: 0, started: false,
      matchScore: [0, 0], handNumber: 0
    };
    rooms[code] = room;
    socket.join(code);
    socket.data.code = code;
    socket.data.token = token;
    socket.emit('room-created', { code, token, playerIndex: 0 });
    io.to(code).emit('room-update', roomSummary(room));
  });

  socket.on('join-room', ({ code, name }) => {
    code = (code || '').toUpperCase().trim();
    const room = rooms[code];
    if (!room) return socket.emit('room-error', { message: 'اتاقی با این کد پیدا نشد.' });
    if (room.players.length >= 2) return socket.emit('room-error', { message: 'این اتاق پر است.' });

    const token = genToken();
    room.players.push({ token, socketId: socket.id, name: (name || 'بازیکن ۲').slice(0, 20), connected: true, hand: [], captured: [], sweeps: 0, disconnectTimer: null });
    socket.join(code);
    socket.data.code = code;
    socket.data.token = token;
    socket.emit('room-joined', { code, token, playerIndex: 1 });
    io.to(code).emit('room-update', roomSummary(room));
  });

  socket.on('reconnect-room', ({ code, token }) => {
    code = (code || '').toUpperCase().trim();
    const room = rooms[code];
    if (!room) return socket.emit('room-error', { message: 'اتاق دیگر وجود ندارد.' });
    const idx = room.players.findIndex(p => p.token === token);
    if (idx === -1) return socket.emit('room-error', { message: 'نشست معتبر نیست.' });

    const player = room.players[idx];
    if (player.disconnectTimer) { clearTimeout(player.disconnectTimer); player.disconnectTimer = null; }
    player.socketId = socket.id;
    player.connected = true;
    socket.join(code);
    socket.data.code = code;
    socket.data.token = token;

    socket.emit('room-joined', { code, token, playerIndex: idx });
    if (room.started) {
      socket.emit('game-start', publicState(room, idx));
    }
    io.to(code).emit('room-update', roomSummary(room));
    socket.to(code).emit('chat-message', { system: true, text: `${player.name} دوباره وصل شد.`, ts: Date.now() });
  });

  socket.on('start-game', () => {
    const room = rooms[socket.data.code];
    if (!room || room.players.length < 2) return;
    room.started = true;
    room.matchScore = [0, 0];
    room.handNumber = 0;
    dealHand(room);
    room.players.forEach((p, idx) => {
      if (p.socketId) io.to(p.socketId).emit('game-start', publicState(room, idx));
    });
    io.to(room.code).emit('room-update', roomSummary(room));
  });

  socket.on('play-card', ({ cardId, selectedTableCardIds }) => {
    const room = rooms[socket.data.code];
    if (!room || !room.started) return;
    const idx = room.players.findIndex(p => p.token === socket.data.token);
    if (idx === -1 || room.turn !== idx) return;

    const player = room.players[idx];
    const cardIdx = player.hand.findIndex(c => c.id === cardId);
    if (cardIdx === -1) return;
    const card = player.hand[cardIdx];
    const selected = new Set(selectedTableCardIds || []);
    const selectedCards = room.table.filter(c => selected.has(c.id));

    let captured = [];
    let valid = false;

    if (card.rank === 'J') {
      captured = [...room.table];
      valid = true;
    } else if (selectedCards.length === 0) {
      valid = true; // trail: place on table
    } else if (selectedCards.every(c => c.rank === card.rank)) {
      captured = selectedCards;
      valid = true;
    } else if (card.sumEligible && selectedCards.every(c => c.sumEligible)) {
      const sum = selectedCards.reduce((s, c) => s + c.value, 0);
      if (sum === card.value) { captured = selectedCards; valid = true; }
    }

    if (!valid) {
      socket.emit('invalid-move', { message: 'این حرکت مطابق قوانین پاسور نیست.' });
      return;
    }

    player.hand.splice(cardIdx, 1);

    let sweep = false;
    if (captured.length > 0) {
      const capturedIds = new Set(captured.map(c => c.id));
      room.table = room.table.filter(c => !capturedIds.has(c.id));
      player.captured.push(card, ...captured);
      room.lastCapturedBy = idx;
      if (room.table.length === 0) {
        sweep = true;
        player.sweeps += 1;
      }
    } else {
      room.table.push(card);
    }

    dealMoreIfNeeded(room);

    if (handIsOver(room)) {
      if (room.table.length > 0 && room.lastCapturedBy !== null) {
        room.players[room.lastCapturedBy].captured.push(...room.table);
        room.table = [];
      }
      const result = scoreHand(room);
      room.matchScore[0] += result.points[0];
      room.matchScore[1] += result.points[1];

      const matchOver = room.matchScore[0] >= MATCH_TARGET_SCORE || room.matchScore[1] >= MATCH_TARGET_SCORE;

      room.players.forEach((p, i) => {
        if (p.socketId) {
          io.to(p.socketId).emit('hand-over', {
            breakdown: result.breakdown,
            handPoints: result.points,
            matchScore: room.matchScore,
            matchOver,
            winner: matchOver ? (room.matchScore[0] > room.matchScore[1] ? 0 : 1) : null
          });
        }
      });

      if (matchOver) {
        room.started = false;
      } else {
        dealHand(room);
        room.players.forEach((p, i) => {
          if (p.socketId) io.to(p.socketId).emit('game-start', publicState(room, i));
        });
      }
      return;
    }

    room.turn = 1 - idx;
    broadcastState(room, sweep ? { type: 'sweep', by: idx } : { type: card.rank === 'J' ? 'jack' : (captured.length ? 'capture' : 'trail'), by: idx, card });
  });

  socket.on('chat-message', ({ text }) => {
    const room = rooms[socket.data.code];
    if (!room || !text || !text.trim()) return;
    const idx = room.players.findIndex(p => p.token === socket.data.token);
    if (idx === -1) return;
    io.to(room.code).emit('chat-message', { name: room.players[idx].name, text: text.slice(0, 300), ts: Date.now(), from: idx });
  });

  socket.on('leave-room', () => {
    handleDisconnect(socket, true);
  });

  socket.on('disconnect', () => {
    handleDisconnect(socket, false);
  });

  function handleDisconnect(socket, explicit) {
    const code = socket.data.code;
    const room = rooms[code];
    if (!room) return;
    const idx = room.players.findIndex(p => p.token === socket.data.token);
    if (idx === -1) return;
    const player = room.players[idx];
    player.connected = false;
    player.socketId = null;
    io.to(code).emit('room-update', roomSummary(room));
    io.to(code).emit('chat-message', { system: true, text: `${player.name} قطع شد. در انتظار اتصال مجدد...`, ts: Date.now() });

    if (explicit) {
      delete rooms[code];
      io.to(code).emit('room-error', { message: 'حریف از بازی خارج شد.' });
      return;
    }

    player.disconnectTimer = setTimeout(() => {
      if (rooms[code]) {
        io.to(code).emit('room-error', { message: 'حریف بیش از حد مجاز وصل نشد، اتاق بسته شد.' });
        delete rooms[code];
      }
    }, RECONNECT_GRACE_MS);
  }
});

const PORT = process.env.PORT || 3000;
http.listen(PORT, () => {
  console.log(`🃏 سرور پاسور پیشرفته روی پورت ${PORT} روشن شد!`);
});
