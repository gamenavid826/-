const socket = io();

const el = (id) => document.getElementById(id);
const screens = { lobby: el('screen-lobby'), waiting: el('screen-waiting'), game: el('screen-game') };
function showScreen(name) {
  Object.values(screens).forEach(s => s.classList.remove('active'));
  screens[name].classList.add('active');
}

let session = JSON.parse(localStorage.getItem('pasur-session') || 'null');
let myIndex = null;
let selectedHandCard = null;
let selectedTableIds = new Set();
let currentState = null;

function saveSession(data) {
  session = { ...session, ...data };
  localStorage.setItem('pasur-session', JSON.stringify(session));
}

function toast(text) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = text;
  el('toast-holder').appendChild(t);
  setTimeout(() => t.remove(), 2600);
}

const persianDigits = (n) => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);

// ---------------- Lobby ----------------
el('btn-create').addEventListener('click', () => {
  const name = el('name-input').value.trim() || 'بازیکن ۱';
  socket.emit('create-room', { name });
});

el('btn-join').addEventListener('click', () => {
  const name = el('name-input').value.trim() || 'بازیکن ۲';
  const code = el('code-input').value.trim().toUpperCase();
  if (!code) { el('lobby-error').textContent = 'کد اتاق رو وارد کن.'; return; }
  socket.emit('join-room', { code, name });
});

el('btn-start').addEventListener('click', () => socket.emit('start-game'));

el('btn-copy-code').addEventListener('click', () => {
  const code = el('room-code-display').textContent;
  navigator.clipboard?.writeText(code).then(() => toast('کد کپی شد ✅')).catch(() => {});
});

el('btn-rematch').addEventListener('click', () => {
  localStorage.removeItem('pasur-session');
  location.reload();
});

// ---------------- Socket: room lifecycle ----------------
socket.on('connect', () => {
  if (session && session.code && session.token) {
    socket.emit('reconnect-room', { code: session.code, token: session.token });
  }
});

socket.on('room-created', ({ code, token, playerIndex }) => {
  saveSession({ code, token });
  myIndex = playerIndex;
  el('room-code-display').textContent = code;
  showScreen('waiting');
});

socket.on('room-joined', ({ code, token, playerIndex }) => {
  saveSession({ code, token });
  myIndex = playerIndex;
  el('room-code-display').textContent = code;
  if (screens.game.classList.contains('active')) return; // already mid game via reconnect
  showScreen('waiting');
});

socket.on('room-error', (data) => {
  toast(data.message);
  el('lobby-error').textContent = data.message;
  if (screens.game.classList.contains('active') || screens.waiting.classList.contains('active')) {
    setTimeout(() => {
      localStorage.removeItem('pasur-session');
      location.reload();
    }, 1800);
  }
});

socket.on('room-update', (room) => {
  el('waiting-players').innerHTML = room.players.map(p =>
    `<div class="p-row"><span>${p.name}</span><span><span class="dot ${p.connected ? 'on' : 'off'}"></span>${p.connected ? 'آنلاین' : 'آفلاین'}</span></div>`
  ).join('');
  el('btn-start').disabled = room.players.length < 2;

  if (screens.game.classList.contains('active') && currentState) {
    const opp = room.players[1 - myIndex];
    el('opp-status').textContent = opp && opp.connected ? '' : '⏳ در انتظار اتصال مجدد...';
  }
});

// ---------------- Game state ----------------
socket.on('game-start', (state) => {
  myIndex = state.myIndex;
  selectedHandCard = null;
  selectedTableIds = new Set();
  currentState = state;
  showScreen('game');
  render(state);
  toast('دست جدید شروع شد 🎴');
});

socket.on('state-update', (state) => {
  currentState = state;
  render(state);
  if (state.note) narrate(state.note);
});

socket.on('invalid-move', (data) => toast('❌ ' + data.message));

socket.on('hand-over', ({ breakdown, handPoints, matchScore, matchOver, winner }) => {
  el('recap-me').textContent = persianDigits(matchScore[myIndex]);
  el('recap-opp').textContent = persianDigits(matchScore[1 - myIndex]);
  el('hand-breakdown').innerHTML = breakdown.length
    ? breakdown.map(b => `<li>${b}</li>`).join('')
    : '<li>امتیاز خاصی این دست ثبت نشد.</li>';
  el('hand-over-title').textContent = `پایان دست — شما ${handPoints[myIndex] >= handPoints[1 - myIndex] ? 'جلویی 👍' : ''}`;

  if (matchOver) {
    el('btn-next-hand').style.display = 'none';
    el('modal-hand-over').classList.remove('open');
    el('match-over-title').textContent = winner === myIndex ? '🏆 شما بردید!' : '😔 حریف برد';
    el('match-over-text').textContent = `امتیاز نهایی: شما ${persianDigits(matchScore[myIndex])} — حریف ${persianDigits(matchScore[1 - myIndex])}`;
    el('modal-match-over').classList.add('open');
  } else {
    el('modal-hand-over').classList.add('open');
  }
});

el('btn-next-hand').addEventListener('click', () => {
  el('modal-hand-over').classList.remove('open');
});

// ---------------- Rendering ----------------
function cardFace(card) {
  const cls = card.color === 'red' ? 'card red' : 'card black';
  return `<div class="card ${cls}" data-id="${card.id}">
      <div class="rank">${card.rank}</div>
      <div class="suit">${card.suit}</div>
      <div class="rank" style="align-self:flex-end;transform:rotate(180deg)">${card.rank}</div>
    </div>`;
}

function render(state) {
  el('score-me').textContent = persianDigits(state.matchScore[myIndex]);
  el('score-opp').textContent = persianDigits(state.matchScore[1 - myIndex]);
  el('deck-count').textContent = '🂠 ' + persianDigits(state.deckCount);
  el('opp-name').textContent = state.opponentName || 'حریف';
  el('opp-status').textContent = state.opponentConnected ? '' : '⏳ در انتظار اتصال مجدد...';
  el('my-captured').textContent = `🂠 ${persianDigits(state.myCaptured)} | 🧹 ${persianDigits(state.mySweeps)}`;
  el('opp-captured').textContent = `🂠 ${persianDigits(state.oppCaptured)} | 🧹 ${persianDigits(state.oppSweeps)}`;

  const myTurn = state.turn === myIndex;
  const ti = el('turn-indicator');
  ti.textContent = myTurn ? 'نوبت شماست' : 'نوبت حریف';
  ti.classList.toggle('not-my-turn', !myTurn);

  el('opponent-hand').innerHTML = Array.from({ length: state.opponentCardCount })
    .map(() => `<div class="card-back"></div>`).join('');

  el('table-cards').innerHTML = state.table.map(cardFace).join('');
  el('my-hand').innerHTML = state.hand.map(cardFace).join('');

  bindHandClicks();
  bindTableClicks();
  updatePlayHint(myTurn);
  updatePlayButton();
}

function bindHandClicks() {
  el('my-hand').querySelectorAll('.card').forEach(node => {
    node.addEventListener('click', () => {
      if (currentState.turn !== myIndex) { toast('نوبت شما نیست ⏳'); return; }
      const id = node.dataset.id;
      selectedHandCard = selectedHandCard === id ? null : id;
      selectedTableIds = new Set();
      updatePlayHint(true);
      renderSelectionState();
      updatePlayButton();
    });
  });
}

function bindTableClicks() {
  el('table-cards').querySelectorAll('.card').forEach(node => {
    node.classList.add('selectable-table');
    node.addEventListener('click', () => {
      if (!selectedHandCard) { toast('اول یه کارت از دست خودت انتخاب کن'); return; }
      const id = node.dataset.id;
      if (selectedTableIds.has(id)) selectedTableIds.delete(id);
      else selectedTableIds.add(id);
      renderSelectionState();
      updatePlayButton();
    });
  });
}

function renderSelectionState() {
  el('my-hand').querySelectorAll('.card').forEach(n => n.classList.toggle('selected', n.dataset.id === selectedHandCard));
  el('table-cards').querySelectorAll('.card').forEach(n => n.classList.toggle('selected', selectedTableIds.has(n.dataset.id)));
}

function updatePlayHint(myTurn) {
  const hint = el('play-hint');
  if (!myTurn) { hint.textContent = ''; return; }
  if (!selectedHandCard) { hint.textContent = 'یه کارت از دستت انتخاب کن'; return; }
  const card = (currentState.hand || []).find(c => c.id === selectedHandCard);
  if (!card) { hint.textContent = ''; return; }
  if (card.rank === 'J') { hint.textContent = 'سرباز 🂡 کل میز رو جمع می‌کنه!'; return; }
  hint.textContent = 'کارت‌های هم‌ارزش یا هم‌جمع رو از میز انتخاب کن، یا بدون انتخاب بگذار روی میز';
}

function updatePlayButton() {
  el('btn-play').disabled = !selectedHandCard || currentState.turn !== myIndex;
}

el('btn-play').addEventListener('click', () => {
  if (!selectedHandCard) return;
  socket.emit('play-card', { cardId: selectedHandCard, selectedTableCardIds: Array.from(selectedTableIds) });
  selectedHandCard = null;
  selectedTableIds = new Set();
});

function narrate(note) {
  if (note.type === 'sweep') toast(note.by === myIndex ? '🧹 پاسور کامل! میز جمع شد' : '🧹 حریف کل میز رو جمع کرد!');
  else if (note.type === 'jack') toast(note.by === myIndex ? '🂡 سرباز زدی، کل میز جمع شد!' : '🂡 حریف سرباز زد و همه چیز رو برد!');
  else if (note.type === 'capture') toast(note.by === myIndex ? 'برداشتی! 👍' : 'حریف کارت برداشت');
}

// ---------------- Chat ----------------
el('btn-chat-toggle').addEventListener('click', () => el('chat-panel').classList.add('open'));
el('btn-chat-close').addEventListener('click', () => el('chat-panel').classList.remove('open'));

el('chat-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const input = el('chat-input');
  const text = input.value.trim();
  if (!text) return;
  socket.emit('chat-message', { text });
  input.value = '';
});

socket.on('chat-message', (msg) => {
  const wrap = el('chat-messages');
  const div = document.createElement('div');
  if (msg.system) {
    div.className = 'chat-msg system';
    div.textContent = msg.text;
  } else {
    div.className = 'chat-msg' + (msg.from === myIndex ? ' mine' : '');
    div.innerHTML = `<span class="who">${msg.name}</span>${escapeHtml(msg.text)}`;
  }
  wrap.appendChild(div);
  wrap.scrollTop = wrap.scrollHeight;
});

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

window.addEventListener('beforeunload', () => {
  // keep session for reconnect; do not emit leave-room here
});
